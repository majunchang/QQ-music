require('babel-register')
require('./src/app')
